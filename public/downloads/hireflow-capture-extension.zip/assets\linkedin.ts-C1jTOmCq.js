function h(t,e){let n=t;for(let r=0;r<e&&n.parentElement;r++)n=n.parentElement;return n}function x(){var t,e,n;try{const r=new URL(window.location.href),c=r.pathname.match(/\/jobs\/view\/(\d+)/),u=r.searchParams.get("currentJobId")??(c==null?void 0:c[1]),o=u?document.querySelector(`a[href*="/jobs/view/${u}/"]`):document.querySelector('a[href*="/jobs/view/"]'),a=(t=o==null?void 0:o.textContent)==null?void 0:t.trim();if(!o||!a)return null;const d=new URL(o.href,window.location.origin),m=`${d.origin}${d.pathname}`,l=h(o,6),s=l.querySelector('a[href*="/company/"]')??document.querySelector('a[href*="/company/"]'),p=(e=s==null?void 0:s.textContent)==null?void 0:e.trim();if(!p)return null;const i=l.querySelector('[class*="job-details"] span[dir="ltr"]'),f=((n=i==null?void 0:i.textContent)==null?void 0:n.trim())??"";return{company:p,role:a,location:f,jobUrl:m,source:"linkedin"}}catch{return null}}function b(){if(document.getElementById("hireFlow-capture-btn"))return;const t=x();if(!t)return;const e=document.createElement("button");e.id="hireFlow-capture-btn",e.textContent="Save to HireFlow",e.style.cssText=`
    position: fixed;
    bottom: 24px;
    left: 24px;
    z-index: 9999;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
  `,e.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"CAPTURED_DRAFT",payload:t}),chrome.runtime.sendMessage({type:"OPEN_POPUP"})}),document.body.appendChild(e)}const w=new MutationObserver(()=>{b()});w.observe(document.body,{childList:!0,subtree:!0});b();
